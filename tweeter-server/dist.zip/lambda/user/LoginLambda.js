"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const UserService_1 = require("../../model/service/UserService");
const DynamoDaoFactory_1 = require("../../dataAccess/factory/DynamoDaoFactory");
const handler = async (request) => {
    const userService = new UserService_1.UserService(new DynamoDaoFactory_1.DynamoDaoFactory());
    //calls the service with the data from the request which is coming from the client
    try {
        const [user, authToken] = await userService.login(request.alias, request.password);
        return {
            success: true,
            message: "user has been logged in",
            user: user,
            authToken: authToken
        };
    }
    catch (error) {
        console.error("Login failed");
        throw error;
    }
};
exports.handler = handler;
