"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const UserService_1 = require("../../model/service/UserService");
const DynamoDaoFactory_1 = require("../../dataAccess/factory/DynamoDaoFactory");
const handler = async (request) => {
    const userService = new UserService_1.UserService(new DynamoDaoFactory_1.DynamoDaoFactory());
    const user = await userService.getUser(request.token, request.alias);
    return {
        success: true,
        message: "here is the user",
        user: user
    };
};
exports.handler = handler;
