"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createFollowUnfollow = void 0;
const DynamoDaoFactory_1 = require("../../dataAccess/factory/DynamoDaoFactory");
const FollowService_1 = require("../../model/service/FollowService");
const createFollowUnfollow = (type) => {
    return async (request) => {
        const followService = new FollowService_1.FollowService(new DynamoDaoFactory_1.DynamoDaoFactory());
        const [followerCount, followeeCount] = await followService.getFollowOrUnfollow(type, request.token, request.userToDoAction);
        return {
            success: true,
            message: null,
            followerCount: followerCount,
            followeeCount: followeeCount
        };
    };
};
exports.createFollowUnfollow = createFollowUnfollow;
