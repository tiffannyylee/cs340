"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const tweeter_shared_1 = require("tweeter-shared");
const FollowService_1 = require("../../model/service/FollowService");
const DynamoDaoFactory_1 = require("../../dataAccess/factory/DynamoDaoFactory");
const handler = async (request) => {
    const followService = new FollowService_1.FollowService(new DynamoDaoFactory_1.DynamoDaoFactory());
    const [items, hasMore] = await followService.loadMoreFollowers(request.token, request.userAlias, request.pageSize, request.lastItem ? tweeter_shared_1.User.fromDto(request.lastItem) : null);
    return {
        success: true,
        message: null,
        items: items,
        hasMore: hasMore
    };
};
exports.handler = handler;
