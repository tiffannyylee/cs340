"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createFollowCountHandler = void 0;
const FollowService_1 = require("../../model/service/FollowService");
const createFollowCountHandler = (type) => {
    return async (request) => {
        const followService = new FollowService_1.FollowService();
        const followCount = await followService.getFollowCount(type, request.token, request.userAlias);
        return {
            success: true,
            message: null,
            followCount: followCount,
        };
    };
};
exports.createFollowCountHandler = createFollowCountHandler;
