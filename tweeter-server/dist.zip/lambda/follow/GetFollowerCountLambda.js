"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const createFollowCountHandler_1 = require("./createFollowCountHandler");
// export const handler= async (request:GetFollowerCountRequest) : Promise<GetFollowerCountResponse>=>{
//     const followService = new FollowService();
//     const followerCount = await followService.getFollowerCount(request.token, request.userAlias)
//     return {
//         success: true,
//         message: null,
//         followerCount: followerCount,
//     }
// }
exports.handler = (0, createFollowCountHandler_1.createFollowCountHandler)("follower");
