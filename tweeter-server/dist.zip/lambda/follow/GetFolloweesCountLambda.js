"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const createFollowCountHandler_1 = require("./createFollowCountHandler");
exports.handler = (0, createFollowCountHandler_1.createFollowCountHandler)("followee");
