"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const createFollowUnfollow_1 = require("./createFollowUnfollow");
exports.handler = (0, createFollowUnfollow_1.createFollowUnfollow)("follow");
