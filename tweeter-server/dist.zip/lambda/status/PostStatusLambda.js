"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const StatusService_1 = require("../../model/service/StatusService");
const DynamoDaoFactory_1 = require("../../dataAccess/factory/DynamoDaoFactory");
const handler = async (request) => {
    const statusService = new StatusService_1.StatusService(new DynamoDaoFactory_1.DynamoDaoFactory());
    try {
        await statusService.postStatus(request.token, request.newStatus);
        return {
            success: true,
            message: "Status posted successfully",
        };
    }
    catch (error) {
        console.error("Error posting status:", error);
        return { success: false, message: "Failed to post status." };
    }
};
exports.handler = handler;
