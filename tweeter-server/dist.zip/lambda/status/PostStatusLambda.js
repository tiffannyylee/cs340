"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const StatusService_1 = require("../../model/service/StatusService");
const DynamoDaoFactory_1 = require("../../dataAccess/factory/DynamoDaoFactory");
const client_sqs_1 = require("@aws-sdk/client-sqs");
const handler = async (request) => {
    let sqsClient = new client_sqs_1.SQSClient({ region: "us-east-1" });
    const statusService = new StatusService_1.StatusService(new DynamoDaoFactory_1.DynamoDaoFactory());
    try {
        await statusService.postStatus(request.token, request.newStatus);
        await sendMessage();
        return {
            success: true,
            message: "Status posted successfully",
        };
    }
    catch (error) {
        console.error("Error posting status:", error);
        return { success: false, message: "Failed to post status." };
    }
    async function sendMessage() {
        const sqs_url = "https://sqs.us-east-1.amazonaws.com/585008063095/PostStatusQueue";
        const messageBody = JSON.stringify({
            token: request.token,
            user_handle: request.newStatus.user.alias,
            status: request.newStatus,
        });
        const params = {
            //DelaySeconds: 10,
            MessageBody: messageBody,
            QueueUrl: sqs_url,
        };
        const data = await sqsClient.send(new client_sqs_1.SendMessageCommand(params));
        console.log("Success, message sent to Post Status Queue. MessageID:", data.MessageId);
    }
};
exports.handler = handler;
