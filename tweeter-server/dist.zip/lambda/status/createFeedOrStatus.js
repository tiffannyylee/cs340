"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createFeedOrStatus = void 0;
const tweeter_shared_1 = require("tweeter-shared");
const StatusService_1 = require("../../model/service/StatusService");
const DynamoDaoFactory_1 = require("../../dataAccess/factory/DynamoDaoFactory");
const createFeedOrStatus = (type) => {
    return async (request) => {
        const statusService = new StatusService_1.StatusService(new DynamoDaoFactory_1.DynamoDaoFactory());
        const [newItems, hasMore] = await statusService.getFeedOrStory(type, request.token, request.userAlias, request.pageSize, request.lastItem ? tweeter_shared_1.Status.fromDto(request.lastItem) : null);
        return {
            success: true,
            message: null,
            newItems: newItems,
            hasMore: hasMore
        };
    };
};
exports.createFeedOrStatus = createFeedOrStatus;
