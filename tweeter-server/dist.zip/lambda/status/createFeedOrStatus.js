"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createFeedOrStatus = void 0;
const StatusService_1 = require("../../model/service/StatusService");
const createFeedOrStatus = (type) => {
    return async (request) => {
        const statusService = new StatusService_1.StatusService();
        const [newItems, hasMore] = await statusService.getFeedOrStory(type, request.token, request.userAlias, request.pageSize, request.lastItem);
        return {
            success: true,
            message: null,
            newItems: newItems,
            hasMore: hasMore
        };
    };
};
exports.createFeedOrStatus = createFeedOrStatus;
