"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_sqs_1 = require("@aws-sdk/client-sqs");
const DynamoDaoFactory_1 = require("../../dataAccess/factory/DynamoDaoFactory");
const FollowService_1 = require("../../model/service/FollowService");
//receives the post and user, gets all the followers for that user, paginated, and sends them to the job q
const handler = async function (event) {
    let sqsClient = new client_sqs_1.SQSClient({ region: "us-east-1" });
    let followService = new FollowService_1.FollowService(new DynamoDaoFactory_1.DynamoDaoFactory());
    //process events
    for (let i = 0; i < event.Records.length; ++i) {
        const body = JSON.parse(event.Records[i].body);
        // needs to read the event and get the followers of the userhandle
        const token = body.token;
        const userHandle = body.user_handle;
        const status = body.status;
        let hasMore = false;
        let lastFollower = null;
        const pageSize = 100;
        do {
            //loadMoreFollowers returns [UserDto, boolean] a list of users and a boolean hasMore
            const [followers, hasMoreResponse] = await followService.loadMoreFollowers(token, userHandle, pageSize, lastFollower); //can change the page size as things get bigger
            const followersHandles = followers.map((follower) => { return follower.alias; });
            await sendMessage(status, followersHandles);
            if (followers.length > 0) {
                lastFollower = followers[followers.length - 1]; // pagination key = last item from current page
            }
            hasMore = hasMoreResponse;
        } while (hasMore);
    }
    //needs to send a message with the followers and the post to the other queue
    async function sendMessage(status, followersHandles) {
        const sqs_url = "https://sqs.us-east-1.amazonaws.com/585008063095/UpdateFeedQueue";
        const messageBody = JSON.stringify({
            followers: followersHandles,
            status: status,
        });
        const params = {
            //DelaySeconds: 10,
            MessageBody: messageBody,
            QueueUrl: sqs_url,
        };
        const data = await sqsClient.send(new client_sqs_1.SendMessageCommand(params));
        console.log("Success, message sent to UpdateFeedQueue. MessageID:", data.MessageId);
    }
};
exports.handler = handler;
