"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_sqs_1 = require("@aws-sdk/client-sqs");
const DynamoDaoFactory_1 = require("../../dataAccess/factory/DynamoDaoFactory");
const StatusService_1 = require("../../model/service/StatusService");
const delay = (ms) => new Promise(res => setTimeout(res, ms));
const handler = async function (event) {
    // this class needs to read the message from the queue, and update the feeds with the info
    let sqsClient = new client_sqs_1.SQSClient({ region: "us-east-1" });
    let statusService = new StatusService_1.StatusService(new DynamoDaoFactory_1.DynamoDaoFactory());
    for (let i = 0; i < event.Records.length; ++i) {
        let body = event.Records[i].body;
        //only parse if string
        if (typeof body === 'string') {
            body = JSON.parse(body);
        }
        const followers = body.followers;
        const status = body.status;
        //i think i need to write a new batch write to feed function
        await statusService.postStatusToFeed(followers, status);
        await delay(10);
    }
    return null;
};
exports.handler = handler;
