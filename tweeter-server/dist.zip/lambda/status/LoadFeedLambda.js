"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const createFeedOrStatus_1 = require("./createFeedOrStatus");
exports.handler = (0, createFeedOrStatus_1.createFeedOrStatus)("feed");
