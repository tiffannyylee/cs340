"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoDaoFactory = void 0;
const FollowsDynamoDao_1 = require("../dynamoDB/FollowsDynamoDao");
const S3DynamoDao_1 = require("../dynamoDB/S3DynamoDao");
const StatusDynamoDao_1 = require("../dynamoDB/StatusDynamoDao");
const UserDynamoDao_1 = require("../dynamoDB/UserDynamoDao");
class DynamoDaoFactory {
    createUserDao() {
        return new UserDynamoDao_1.UserDynamoDao();
    }
    createStatusDao() {
        return new StatusDynamoDao_1.StatusDynamoDao();
    }
    createFollowsDao() {
        return new FollowsDynamoDao_1.FollowsDynamoDao();
    }
    createS3Dao() {
        return new S3DynamoDao_1.S3DynamoDao();
    }
}
exports.DynamoDaoFactory = DynamoDaoFactory;
