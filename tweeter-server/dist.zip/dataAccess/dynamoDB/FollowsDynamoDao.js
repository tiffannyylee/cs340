"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FollowsDynamoDao = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
class FollowsDynamoDao {
    dbClient = new client_dynamodb_1.DynamoDBClient({ region: "us-east-1" });
    db = lib_dynamodb_1.DynamoDBDocumentClient.from(this.dbClient);
    tableName = "follows";
    async getFollowees(followerHandle, pageSize, lastFolloweeHandle) {
        const command = new lib_dynamodb_1.QueryCommand({
            TableName: this.tableName,
            KeyConditionExpression: "follower_handle = :f",
            ExpressionAttributeValues: {
                ":f": followerHandle,
            },
            Limit: pageSize,
            ExclusiveStartKey: lastFolloweeHandle ? { follower_handle: followerHandle, followee_handle: lastFolloweeHandle } : undefined,
        });
        const response = await this.db.send(command);
        console.log(`db response get followees: ${response}`);
        const aliases = response.Items?.map(item => item.followee_handle) ?? [];
        // returns the page with the data and whether there is more
        return [aliases, response.LastEvaluatedKey !== undefined];
    }
    async getFollowers(followeeHandle, pageSize, lastFollowerHandle) {
        const command = new lib_dynamodb_1.QueryCommand({
            TableName: this.tableName,
            IndexName: "follows_index",
            KeyConditionExpression: "followee_handle = :followee",
            ExpressionAttributeValues: {
                ":followee": followeeHandle
            },
            Limit: pageSize,
            ExclusiveStartKey: lastFollowerHandle ? { followeeHandle: followeeHandle, follower_handle: lastFollowerHandle } : undefined,
        });
        const response = await this.db.send(command);
        const aliases = response.Items?.map(item => item.follower_handle) ?? [];
        return [aliases, response.LastEvaluatedKey !== undefined];
    }
    async getAllFollowers(followeeHandle) {
        const command = new lib_dynamodb_1.QueryCommand({
            TableName: this.tableName,
            IndexName: "follows_index",
            KeyConditionExpression: "followee_handle = :followee",
            ExpressionAttributeValues: {
                ":followee": followeeHandle
            }
        });
        const response = await this.db.send(command);
        const aliases = response.Items?.map(item => item.follower_handle) ?? [];
        return aliases;
    }
    async getFolloweeCount(followerHandle) {
        const command = new lib_dynamodb_1.QueryCommand({
            TableName: this.tableName,
            KeyConditionExpression: "follower_handle = :f",
            ExpressionAttributeValues: {
                ":f": followerHandle
            },
            Select: "COUNT"
        });
        const response = await this.db.send(command);
        return response.Count ?? 0;
    }
    async getFollowerCount(followeeHandle) {
        const command = new lib_dynamodb_1.QueryCommand({
            TableName: this.tableName,
            IndexName: "follows_index",
            KeyConditionExpression: "followee_handle = :f",
            ExpressionAttributeValues: {
                ":f": followeeHandle
            },
            Select: "COUNT"
        });
        const response = await this.db.send(command);
        return response.Count ?? 0;
    }
    async createFollowee(follower, followee) {
        const command = new lib_dynamodb_1.PutCommand({
            TableName: this.tableName,
            Item: {
                follower_handle: follower,
                followee_handle: followee
            }
        });
        await this.db.send(command);
    }
    async removeFollow(follower, followee) {
        const command = new lib_dynamodb_1.DeleteCommand({
            TableName: this.tableName,
            Key: {
                follower_handle: follower,
                followee_handle: followee
            }
        });
        await this.db.send(command);
    }
    async isFollower(user, selectedUser) {
        //check if user is in the follower list of selected user or if selected user is in the followee list of user
        const command = new lib_dynamodb_1.QueryCommand({
            TableName: this.tableName,
            KeyConditionExpression: "follower_handle = :f AND followee_handle = :e",
            ExpressionAttributeValues: {
                ":f": user,
                ":e": selectedUser
            }
        });
        const result = await this.db.send(command);
        return (result.Items?.length ?? 0) > 0;
    }
}
exports.FollowsDynamoDao = FollowsDynamoDao;
