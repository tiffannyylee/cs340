"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatusDynamoDao = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
class StatusDynamoDao {
    dbClient = new client_dynamodb_1.DynamoDBClient({ region: "us-east-1" });
    db = lib_dynamodb_1.DynamoDBDocumentClient.from(this.dbClient);
    storyTableName = "story";
    feedTableName = "feed";
    // async getFeed(handle: string, pageSize: number, lastItem?: StatusDto): Promise<[RawStatusFromDb[], boolean]> {
    //     //for the current user, query the feed table by their handle
    //     //sort the entries by time
    //     const command = new QueryCommand({
    //         TableName: this.feedTableName,
    //         KeyConditionExpression: "user_handle = :h",
    //         ExpressionAttributeValues: {
    //             ":h": handle,
    //         },
    //         Limit: pageSize,
    //         ScanIndexForward: false,
    //         ExclusiveStartKey: lastItem
    //         ? {
    //             user_handle: handle,
    //             timestamp: lastItem.timestamp
    //           }
    //         : undefined
    //     })
    //     const response = await this.db.send(command)
    //     const statuses: RawStatusFromDb[] = (response.Items ?? []).map(item => ({
    //         author_handle: item.author_handle, // or fetch full user info if needed
    //         post: item.post,
    //         timestamp: item.timestamp,
    //     }));
    //     return [statuses, !!response.LastEvaluatedKey];
    // }
    async getStatus(tableName, keyAttr, handle, pageSize, lastItem) {
        //for the current user, query the feed table by their handle
        //sort the entries by time
        const command = new lib_dynamodb_1.QueryCommand({
            TableName: tableName,
            KeyConditionExpression: `${keyAttr} = :h`,
            ExpressionAttributeValues: {
                ":h": handle,
            },
            Limit: pageSize,
            ScanIndexForward: false,
            ExclusiveStartKey: lastItem
                ? {
                    [keyAttr]: handle,
                    timestamp: lastItem.timestamp
                }
                : undefined
        });
        const response = await this.db.send(command);
        const statuses = (response.Items ?? []).map(item => ({
            author_handle: item.author_handle, // or fetch full user info if needed
            post: item.post,
            timestamp: item.timestamp,
        }));
        return [statuses, !!response.LastEvaluatedKey];
    }
    async postStatusToStory(status) {
        //for the logged in user, adds it to the story table with their handle as the pk, the status, and the timestamp
        const command = new lib_dynamodb_1.PutCommand({
            TableName: this.storyTableName,
            Item: {
                author_handle: status.user.alias,
                timestamp: status.timestamp,
                post: status.post
            }
        });
        await this.db.send(command);
    }
    async postStatusToFeed(userHandle, status) {
        //for each follower of the logged in user, post the status under their feed and sort by order
        try {
            const command = new lib_dynamodb_1.PutCommand({
                TableName: this.feedTableName,
                Item: {
                    user_handle: userHandle,
                    timestamp: status.timestamp,
                    author_handle: status.user.alias,
                    post: status.post
                }
            });
            await this.db.send(command);
        }
        catch (error) {
            console.error(`Failed to post to ${userHandle}'s feed`, error);
            throw error; // Re-throw to catch in calling code
        }
    }
}
exports.StatusDynamoDao = StatusDynamoDao;
