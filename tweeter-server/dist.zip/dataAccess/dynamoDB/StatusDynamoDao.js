"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatusDynamoDao = void 0;
class StatusDynamoDao {
    getFeed(handle, time) {
        throw new Error("Method not implemented.");
    }
    getStory(handle, time) {
        throw new Error("Method not implemented.");
    }
    postStatus(status) {
        throw new Error("Method not implemented.");
    }
}
exports.StatusDynamoDao = StatusDynamoDao;
