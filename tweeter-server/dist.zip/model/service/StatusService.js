"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatusService = void 0;
class StatusService {
    followDao;
    userDao;
    s3Dao;
    statusDao;
    constructor(daoFactory) {
        this.followDao = daoFactory.createFollowsDao();
        this.userDao = daoFactory.createUserDao();
        this.s3Dao = daoFactory.createS3Dao();
        this.statusDao = daoFactory.createStatusDao();
    }
    async loadMoreStatusItems(tableName, keyName, userAlias, pageSize, lastItem) {
        const [rawStatuses, hasMore] = await this.statusDao.getStatus(tableName, keyName, userAlias, pageSize, lastItem ?? undefined);
        const aliases = [...new Set(rawStatuses.map((s) => s.author_handle))];
        const users = await this.userDao.batchGetUsersByAliases(aliases);
        const userMap = new Map(users.map((u) => [u.alias, u]));
        const statuses = rawStatuses.map((s) => {
            return { post: s.post,
                user: userMap.get(s.author_handle),
                timestamp: s.timestamp };
        });
        if (statuses.length == 0) {
            return [[], hasMore];
        }
        return [statuses, hasMore];
    }
    async loadMoreFeedItems(authToken, userAlias, pageSize, lastItem) {
        // TODO: Replace with the result of calling server
        const [rawStatuses, hasMore] = await this.statusDao.getStatus("feed", "user_handle", userAlias, pageSize, lastItem ?? undefined);
        const aliases = [...new Set(rawStatuses.map((s) => s.author_handle))];
        const users = await this.userDao.batchGetUsersByAliases(aliases);
        const userMap = new Map(users.map((u) => [u.alias, u]));
        const statuses = rawStatuses.map((s) => {
            return { post: s.post,
                user: userMap.get(s.author_handle),
                timestamp: s.timestamp };
        });
        if (statuses.length == 0) {
            return [[], hasMore];
        }
        return [statuses, hasMore];
    }
    ;
    async loadMoreStoryItems(authToken, userAlias, pageSize, lastItem) {
        // TODO: Replace with the result of calling server
        // const [newItems, hasMore] = FakeData.instance.getPageOfStatuses(Status.fromDto(lastItem), pageSize);
        // const dtos = newItems.map((status:Status)=>status.dto)
        // return [dtos, hasMore]
        return await this.loadMoreStatusItems("story", "author_handle", userAlias, pageSize, lastItem);
    }
    ;
    async getFeedOrStory(type, authToken, userAlias, pageSize, lastItem) {
        if (type == "feed") {
            return await this.loadMoreFeedItems(authToken, userAlias, pageSize, lastItem);
        }
        else {
            return await this.loadMoreStoryItems(authToken, userAlias, pageSize, lastItem);
        }
    }
    async postStatus(token, newStatus) {
        // Pause so we can see the logging out message. Remove when connected to the server
        //await new Promise((f) => setTimeout(f, 2000));
        // TODO: Call the server to post the status
        //send as dto
        //add to story table for user
        //go to feed
        const { authToken, handle } = await this.getAuthFromQuery(token);
        await this.statusDao.postStatusToStory(newStatus);
        //this gets all followers of the user whos token was passed in
        const followers = await this.followDao.getAllFollowers(handle);
        console.log(`Followers of ${handle}:`, followers);
        await Promise.all(followers.map((follower) => this.statusDao.postStatusToFeed(follower, newStatus)));
    }
    ;
    async getAuthFromQuery(token) {
        const authInfo = await this.userDao.getAuth(token);
        if (authInfo == null) {
            throw new Error("auth is null");
        }
        const authToken = authInfo[0];
        const handle = authInfo[1];
        return { authToken, handle };
    }
}
exports.StatusService = StatusService;
