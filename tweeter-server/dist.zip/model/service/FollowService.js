"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FollowService = void 0;
const tweeter_shared_1 = require("tweeter-shared");
class FollowService {
    followDao;
    userDao;
    s3Dao;
    constructor(daoFactory) {
        this.followDao = daoFactory.createFollowsDao();
        this.userDao = daoFactory.createUserDao();
        this.s3Dao = daoFactory.createS3Dao();
    }
    async getAliasAndPassword(alias) {
        const userRecord = await this.userDao.getUser(alias);
        console.log(userRecord);
        if (userRecord == null) {
            throw new Error("alias or password incorrect");
        }
        const user = userRecord[0];
        const hashedPassword = userRecord[1];
        return { hashedPassword, user };
    }
    async getAuthFromQuery(token) {
        const authInfo = await this.userDao.getAuth(token);
        if (authInfo == null) {
            throw new Error("auth is null");
        }
        const authToken = authInfo[0];
        const handle = authInfo[1];
        return { authToken, handle };
    }
    async loadMoreFollowers(token, userAlias, pageSize, lastItem) {
        // TODO: Replace with the result of calling server
        //return a list of aliases, query the user table for each to get a list of users
        const [items, hasMore] = tweeter_shared_1.FakeData.instance.getPageOfUsers(tweeter_shared_1.User.fromDto(lastItem), pageSize, userAlias);
        // const [items, hasMore] =  await this.followDao.getFollowers()
        const dtos = items.map((user) => user.dto);
        return [dtos, hasMore];
    }
    ;
    async loadMoreFollowees(token, userAlias, pageSize, lastItem) {
        // TODO: Replace with the result of calling server
        //const [items, hasMore] = FakeData.instance.getPageOfUsers(User.fromDto(lastItem), pageSize, userAlias);
        //return a list of aliases, query the user table for each to get a list of users
        const lastFolloweeHandle = lastItem ? lastItem.alias : null;
        const [items, hasMore] = await this.followDao.getFollowees(userAlias, pageSize, lastFolloweeHandle);
        console.log(`loadfollowees: items:${items}`);
        if (items.length == 0) {
            items.push('@bethspack');
        }
        const users = await this.userDao.batchGetUsersByAliases(items);
        console.log(`loadfollowees: users:${users}`);
        return [users, hasMore];
    }
    ;
    async getIsFollowerStatus(token, user, selectedUser) {
        // TODO: Replace with the result of calling server
        //query to see if the selected follower is in the followers list of the user
        return tweeter_shared_1.FakeData.instance.isFollower();
    }
    ;
    async getFolloweeCount(token, userAlias) {
        // TODO: Replace with the result of calling server
        //query the table for count of entries
        // return FakeData.instance.getFolloweeCount(userAlias);
        return this.followDao.getFolloweeCount(userAlias);
    }
    ;
    async getFollowerCount(token, userAlias) {
        // TODO: Replace with the result of calling server
        //query the index table
        return this.followDao.getFollowerCount(userAlias);
    }
    ;
    async getFollowCount(type, token, userAlias) {
        if (type === "follower") {
            return await this.getFollowerCount(token, userAlias);
        }
        else {
            return await this.getFolloweeCount(token, userAlias);
        }
    }
    async follow(token, userToFollow) {
        // Pause so we can see the follow message. Remove when connected to the server
        //await new Promise((f) => setTimeout(f, 2000));
        // TODO: Call the server
        const { authToken, handle } = await this.getAuthFromQuery(token);
        await this.followDao.createFollowee(handle, userToFollow);
        const followerCount = await this.getFollowerCount(token, userToFollow);
        const followeeCount = await this.getFolloweeCount(token, userToFollow);
        return [followerCount, followeeCount];
    }
    ;
    async unfollow(token, userToUnfollow) {
        // Pause so we can see the unfollow message. Remove when connected to the server
        //await new Promise((f) => setTimeout(f, 2000));
        // TODO: Call the server
        const { authToken, handle } = await this.getAuthFromQuery(token);
        await this.followDao.removeFollow(handle, userToUnfollow);
        const followerCount = await this.getFollowerCount(token, userToUnfollow);
        const followeeCount = await this.getFolloweeCount(token, userToUnfollow);
        return [followerCount, followeeCount];
    }
    ;
    async getFollowOrUnfollow(type, token, userToDoAction) {
        if (type === "follow") {
            return await this.follow(token, userToDoAction);
        }
        else {
            return await this.unfollow(token, userToDoAction);
        }
    }
}
exports.FollowService = FollowService;
