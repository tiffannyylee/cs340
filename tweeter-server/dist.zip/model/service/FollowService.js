"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FollowService = void 0;
class FollowService {
    followDao;
    userDao;
    s3Dao;
    constructor(daoFactory) {
        this.followDao = daoFactory.createFollowsDao();
        this.userDao = daoFactory.createUserDao();
        this.s3Dao = daoFactory.createS3Dao();
    }
    normalizeAlias(alias) {
        return alias.startsWith("@") ? alias : `@${alias}`;
    }
    async getAuthFromQuery(token) {
        const authInfo = await this.userDao.getAuth(token);
        if (authInfo == null) {
            throw new Error("Bad Request: Invalid or Expired Authtoken");
        }
        const authToken = authInfo[0];
        const handle = authInfo[1];
        return { authToken, handle };
    }
    async loadUsersByFollowType(type, userAlias, pageSize, lastItem) {
        userAlias = this.normalizeAlias(userAlias);
        const lastHandle = lastItem ? lastItem.alias : null;
        const [aliases, hasMore] = type === "followers"
            ? await this.followDao.getFollowers(userAlias, pageSize, lastHandle)
            : await this.followDao.getFollowees(userAlias, pageSize, lastHandle);
        if (aliases.length === 0) {
            return [[], false];
        }
        const users = await this.userDao.batchGetUsersByAliases(aliases);
        return [users, hasMore];
    }
    async loadMoreFollowers(token, userAlias, pageSize, lastItem) {
        //userAlias = this.normalizeAlias(userAlias)
        return this.loadUsersByFollowType("followers", userAlias, pageSize, lastItem);
    }
    ;
    async loadMoreFollowees(token, userAlias, pageSize, lastItem) {
        return this.loadUsersByFollowType("followees", userAlias, pageSize, lastItem);
    }
    ;
    async getIsFollowerStatus(token, user, selectedUser) {
        //query to see if the selected follower is in the followers list of the user
        const isFollower = this.followDao.isFollower(this.normalizeAlias(user.alias), this.normalizeAlias(selectedUser.alias));
        return isFollower;
    }
    ;
    async getFolloweeCount(token, userAlias) {
        //query the table for count of entries
        userAlias = this.normalizeAlias(userAlias);
        return this.followDao.getFolloweeCount(userAlias);
    }
    ;
    async getFollowerCount(token, userAlias) {
        //query the index table
        userAlias = this.normalizeAlias(userAlias);
        return this.followDao.getFollowerCount(userAlias);
    }
    ;
    async getFollowCount(type, token, userAlias) {
        userAlias = this.normalizeAlias(userAlias);
        if (type === "follower") {
            return await this.getFollowerCount(token, userAlias);
        }
        else {
            return await this.getFolloweeCount(token, userAlias);
        }
    }
    async getUpdatedFollowCounts(token, userAlias) {
        const followerCount = await this.getFollowerCount(token, userAlias);
        const followeeCount = await this.getFolloweeCount(token, userAlias);
        return [followerCount, followeeCount];
    }
    async follow(token, userToFollow) {
        userToFollow = this.normalizeAlias(userToFollow);
        const { authToken, handle } = await this.getAuthFromQuery(token);
        await this.followDao.createFollowee(handle, userToFollow);
        // const followerCount = await this.getFollowerCount(token, userToFollow);
        // const followeeCount = await this.getFolloweeCount(token, userToFollow);
        //return [followerCount, followeeCount];
        return this.getUpdatedFollowCounts(token, userToFollow);
    }
    ;
    async unfollow(token, userToUnfollow) {
        userToUnfollow = this.normalizeAlias(userToUnfollow);
        const { authToken, handle } = await this.getAuthFromQuery(token);
        await this.followDao.removeFollow(handle, userToUnfollow);
        // const followerCount = await this.getFollowerCount(token, userToUnfollow);
        // const followeeCount = await this.getFolloweeCount(token, userToUnfollow);
        // return [followerCount, followeeCount];
        return this.getUpdatedFollowCounts(token, userToUnfollow);
    }
    ;
    async getFollowOrUnfollow(type, token, userToDoAction) {
        userToDoAction = this.normalizeAlias(userToDoAction);
        if (type === "follow") {
            return await this.follow(token, userToDoAction);
        }
        else {
            return await this.unfollow(token, userToDoAction);
        }
    }
}
exports.FollowService = FollowService;
