"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const tweeter_shared_1 = require("tweeter-shared");
class UserService {
    async login(alias, password) {
        // TODO: Replace with the result of calling the server
        const user = tweeter_shared_1.FakeData.instance.firstUser;
        if (user === null) {
            throw new Error("Invalid alias or password");
        }
        const userDto = user.dto;
        const authDto = (tweeter_shared_1.FakeData.instance.authToken).dto;
        //return a dto to send back to client
        return [userDto, authDto];
    }
    ;
    async register(firstName, lastName, alias, password, userImageBytes, //Uint8Array,
    imageFileExtension) {
        // Not neded now, but will be needed when you make the request to the server in milestone 3
        // const imageStringBase64: string = Buffer.from(userImageBytes).toString("base64");
        // TODO: Replace with the result of calling the server
        const user = tweeter_shared_1.FakeData.instance.firstUser;
        if (user === null) {
            throw new Error("Invalid registration");
        }
        const userDto = user.dto;
        const authDto = (tweeter_shared_1.FakeData.instance.authToken).dto;
        return [userDto, authDto];
    }
    ;
    async getUser(authToken, alias) {
        // TODO: Replace with the result of calling server
        const user = tweeter_shared_1.FakeData.instance.findUserByAlias(alias);
        if (user == null) {
            return null;
        }
        return user.dto;
    }
    ;
    async logout(authToken) {
        // Pause so we can see the logging out message. Delete when the call to the server is implemented.
        await new Promise((res) => setTimeout(res, 1000));
    }
    ;
}
exports.UserService = UserService;
