"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const tweeter_shared_1 = require("tweeter-shared");
const buffer_1 = require("buffer");
const bcryptjs_1 = __importDefault(require("bcryptjs"));
class UserService {
    s3Dao;
    userDao;
    constructor(daoFactory) {
        this.s3Dao = daoFactory.createS3Dao();
        this.userDao = daoFactory.createUserDao();
    }
    async login(alias, password) {
        // TODO: Replace with the result of calling the server
        // const user = FakeData.instance.firstUser; 
        const { hashedPassword, user } = await this.getAliasAndPassword(alias);
        const isPasswordValid = await bcryptjs_1.default.compare(password, hashedPassword);
        if (!isPasswordValid) {
            throw new Error("Bad Request: this password is not valid");
        }
        if (user === null) {
            throw new Error("Invalid alias or password");
        }
        //const userDto = user.dto
        const token = this.generateAuthToken();
        await this.userDao.createAuth(user.alias, token);
        const authToken = await this.getAuthFromQuery(token);
        //return a dto to send back to client
        return [user, authToken];
    }
    ;
    async getAliasAndPassword(alias) {
        const userRecord = await this.userDao.getUser(alias);
        console.log(userRecord);
        if (userRecord == null) {
            throw new Error("alias or password incorrect");
        }
        const user = userRecord[0];
        const hashedPassword = userRecord[1];
        return { hashedPassword, user };
    }
    async getAuthFromQuery(token) {
        const authInfo = await this.userDao.getAuth(token);
        if (authInfo == null) {
            throw new Error("auth is null");
        }
        const authToken = authInfo[0];
        const handle = authInfo[1];
        return authToken;
    }
    async register(firstName, lastName, alias, password, userImageBytes, //Uint8Array,
    imageFileExtension) {
        // Not neded now, but will be needed when you make the request to the server in milestone 3
        const imageStringBase64 = buffer_1.Buffer.from(userImageBytes).toString("base64");
        const fileName = `${alias}-profile-pic`;
        // Upload to S3
        const imageUrl = await this.s3Dao.putImage(fileName, imageStringBase64);
        //hash password to store in db
        const salt = await bcryptjs_1.default.genSalt(10);
        const hashedPass = await bcryptjs_1.default.hash(password, salt);
        // create user and create auth
        const user = new tweeter_shared_1.User(firstName, lastName, alias, imageUrl);
        await this.userDao.createUser(user, hashedPass);
        const token = this.generateAuthToken();
        await this.userDao.createAuth(user.alias, token);
        await new Promise(resolve => setTimeout(resolve, 100));
        let attempt = 0;
        let authInfo = null;
        while (attempt < 3 && !authInfo) {
            authInfo = await this.userDao.getAuth(token);
            if (!authInfo) {
                await new Promise(resolve => setTimeout(resolve, 100)); // Wait for 100ms
            }
            attempt++;
        }
        if (!authInfo) {
            throw new Error("Auth token not found after multiple attempts");
        }
        //const authInfo = await this.userDao.getAuth(token)
        // const user = FakeData.instance.firstUser;
        if (user === null) {
            throw new Error("Invalid registration");
        }
        const userDto = user.dto;
        // const authDto = (FakeData.instance.authToken).dto
        if (authInfo == null) {
            throw new Error("auth is null");
        }
        const authToken = authInfo[0];
        const handle = authInfo[1];
        return [userDto, authToken];
    }
    ;
    generateAuthToken() {
        return Math.random().toString(36).substring(2); // Simple token generation
    }
    async getUser(authToken, alias) {
        // TODO: Replace with the result of calling server
        // const user = FakeData.instance.findUserByAlias(alias);
        const userInfo = await this.userDao.getUser(alias);
        if (userInfo == null) {
            return null;
        }
        const user = userInfo[0];
        return user;
    }
    ;
    async logout(authToken) {
        // Pause so we can see the logging out message. Delete when the call to the server is implemented.
        await new Promise((res) => setTimeout(res, 1000));
    }
    ;
}
exports.UserService = UserService;
