export const Temp = ()=> {
    console.log("I love seth!")
}